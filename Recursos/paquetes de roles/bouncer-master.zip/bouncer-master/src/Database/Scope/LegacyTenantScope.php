<?php

namespace Silber\Bouncer\Database\Scope;

use Illuminate\Database\Eloquent\ScopeInterface;

class LegacyTenantScope extends BaseTenantScope implements ScopeInterface
{
    //
}
